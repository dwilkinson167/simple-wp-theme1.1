<footer>
	<div class="container">
		<p>&copy; <?php the_date('Y'); ?> - <?php bloginfo('name'); ?></p>
		</div>
	</footer>

	<?php wp_footer(); ?>
</body>
</html>